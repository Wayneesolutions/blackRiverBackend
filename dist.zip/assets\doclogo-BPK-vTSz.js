const o="/assets/doclogo-CrDUrcfS.png";export{o as D};
