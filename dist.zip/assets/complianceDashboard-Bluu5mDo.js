import{D as a}from"./index-CDFoL78g.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
