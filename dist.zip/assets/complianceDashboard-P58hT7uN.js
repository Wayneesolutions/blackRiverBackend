import{C as a}from"./index-CiV5HKWD.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
