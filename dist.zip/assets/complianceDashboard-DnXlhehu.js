import{D as a}from"./index-DK_F59j9.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
