import{C as a}from"./index-h0cMb2M0.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
