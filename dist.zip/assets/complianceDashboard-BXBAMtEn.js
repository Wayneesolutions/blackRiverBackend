import{D as a}from"./index-CtPn38wo.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
