import{D as a}from"./index--SAj0x0C.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
