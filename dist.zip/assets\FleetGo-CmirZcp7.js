const o="/assets/FleetGo-JtuXzbXp.png";export{o as F};
