import{C as a}from"./index-CFAWd5_-.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
