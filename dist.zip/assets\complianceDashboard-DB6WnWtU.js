import{C as a}from"./index-BuNo7ewc.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
